/* script.js - demo calculations */
function parseFloatSafe(v){return v===''?0:parseFloat(v)||0}

function runDemo(){
  const area = parseFloatSafe(document.getElementById('roofArea').value) // m2
  const rainfall = parseFloatSafe(document.getElementById('rainfall').value) // mm/year
  const percolation = parseFloatSafe(document.getElementById('percolation').value) // mm/hr
  const roofSel = document.getElementById('roofMaterial')
  const coeff = parseFloatSafe(roofSel.options[roofSel.selectedIndex].dataset.coeff)

  // harvestable water (m3/year) = area (m2) * rainfall (mm)/1000 * runoff_coeff
  const harvest_m3 = area * (rainfall/1000) * coeff
  const harvest_rounded = Math.round(harvest_m3*100)/100

  // recommended tank: use rule-of-thumb: 10% of annual harvest (in litres) capped reasonably
  let tank_l = Math.round(harvest_m3 * 1000 * 0.10)
  if(tank_l<1000) tank_l = 1000
  if(tank_l>harvest_m3*1000) tank_l = Math.round(harvest_m3*1000)

  // recharge suggestion (pit/trench/shaft) simple heuristic
  let rechargeOption = ''
  if(percolation <= 5) rechargeOption = 'Recharge shaft / bore-pit (low percolation)'
  else if(percolation <= 20) rechargeOption = 'Recharge pit / soakaway (moderate percolation)'
  else rechargeOption = 'Recharge trench (high percolation)'

  // update UI
  document.getElementById('harvestable').textContent = harvest_rounded + ' m³ / year'
  document.getElementById('tankSize').textContent = tank_l.toLocaleString() + ' L'
  document.getElementById('rechargeDesc').textContent = rechargeOption

  // small mock values for hero mock-phone
  document.getElementById('demo-harvest').textContent = (Math.round(harvest_m3*10)/10)
  document.getElementById('demo-tank').textContent = tank_l.toLocaleString() + ' L'
  document.getElementById('demo-recharge').textContent = rechargeOption
}

function resetDemo(){
  document.getElementById('roofArea').value = 100
  document.getElementById('rainfall').value = 800
  document.getElementById('percolation').value = 10
  document.getElementById('roofMaterial').selectedIndex = 0
  runDemo()
}

// run initial demo values on load
document.addEventListener('DOMContentLoaded', function(){ runDemo() })
